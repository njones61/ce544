README file for the UTEXASED4 - Educational version of the UTEXAS4 and TexGraf4 software for slope stability calculations  This document applies to the electronically transmitted (CD-ROM or email) distributed version of UTEXASED4.  A different README file is applicable to versions distributed on diskette.  

The current version of UTEXASED4 has been recently revised and probably contains some errors.  

This software is made available for educational purposes only.  It may not be used for any commercial or research purposes.

Most of the files for UTEXASED4 are contained in a ".zip" file and must be extracted using an appropriate "unzip" utility.  Because of filters on many current email systems that automatically scan and block "zip" files or zip files that contain executable code, we have changed the extension of the zip file to ".XYZ".  After you receive the file, you must manually change the extension from "XYZ" to "ZIP".

You should have received the following three files electronically:

1: UTEXASED4.XYZ

2: Installation Instructions.PDF

3: UTEXASED4.SSR

The UTEXASED4.XYZ file is the "zip" file containing most of the executable, data and documentation files required for UTEXASED4.  Before proceeding further you must change the name of this file from "UTEXASED4.XYZ" to "UTEXASED4.ZIP".  Refer to this document for complete instructions on installation of the UTEXASED4 software.

The "Installation Instructions.PDF" file is an Adobe Acrobat "pdf" file that describes how to install UTEXASED4.  To read this file you will need Adobe Acrobat or the free Adobe Acrobat reader (see www.adobe.com). 

The UTEXASED4.SSR file is a special "registration file" that is required for you to run UTEXASED4.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
UTEXASED4.XYZ "zip" file contents.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
The UTEXASED4.XYZ file is a "zip" file that must be extracted using a suitable zip extraction utility.  Before ectracting change the name of this file from "UTEXASED4.XYZ" to "UTEXASED4.ZIP".  The zip file contains the following files:

1: README.TXT - This "readme" text file.

2: UTEXASED4 License Agreement.pdf - An Adobe "pdf" file containing the License Agreement for UTEXASED4.  All users must agree to and comply with this Agreement.

3: Utexas Educational.xxe - The executable program for UTEXASED4 (must change name to Utexas Educational.exe).

4: Common.xll - A dynamic link library required by UTEXASED4 (must change name to Common.dll).

5: Contours.xll - A dynamic link library required by UTEXASED4 (must change name to Contours.dll).

6: Dialogs.xll - A dynamic link library required by UTEXASED4 (must change name to Dialogs.dll).

7: Graph.xll - A dynamic link library required by UTEXASED4 (must change name to Graph.dll).

8: ssrxx.xll - A dynamic link library required by UTEXASED4 (must change name to ssrxx.dll).

9: UTEXASED4 User's Manual.pdf - An Adobe "pdf" file containing the user's manual for UTEXASED4.

10: Example Data.pdf - An Adobe "pdf" file containing the description of the example problems for UTEXASED4.

11: Example 1.input-utexased, Example 2.input-utexased, Example 3.input-utexased, Example 4.input-utexased, Example 5.input-utexased: - Input data files for the five example problems described in the "Example Data.pdf" file.
